import { ChevronDown, Linkedin, Github, Mail } from 'lucide-react';
import profileImage from '@assets/WhatsApp Image 2025-07-15 at 04.13.11_73eaff5c_1752534853478.jpg';

const Hero = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="hero" className="min-h-screen flex items-center justify-center relative overflow-hidden stellar-gradient stellar-overlay">
      <div className="container mx-auto px-6 text-center">
        <div className="animate-fadeIn">
          <div className="relative w-52 h-52 mx-auto mb-8 transform hover:scale-105 transition-transform duration-300">
            <div className="profile-image-container w-full h-full rounded-full overflow-hidden border-4 border-white shadow-2xl profile-glow">
              <img 
                src={profileImage} 
                alt="Muhammad Asim - Data Analyst & AI Specialist" 
                className="profile-image w-full h-full object-cover object-center"
                onError={(e) => {
                  console.log('Image failed to load:', e.currentTarget.src);
                  // Fallback if image fails to load
                  e.currentTarget.style.display = 'none';
                }}
                onLoad={() => {
                  console.log('Image loaded successfully');
                }}
              />
            </div>
            <div className="absolute -inset-2 bg-gradient-to-r from-pink-400 via-purple-500 to-indigo-500 rounded-full opacity-30 blur-lg animate-pulse"></div>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-light mb-4 tracking-wide text-white">
            Muhammad Asim
          </h1>
          
          <p className="text-xl md:text-2xl mb-8 text-gray-200 max-w-2xl mx-auto leading-relaxed">
            Data Analyst | AI Specialist
          </p>
          
          <p className="text-lg mb-12 text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Results-driven Data Analyst with expertise in Power BI, AI/ML models, and advanced analytics. 
            Passionate about turning data into actionable insights and business intelligence solutions.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <button 
              onClick={() => scrollToSection('projects')}
              className="bg-accent hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
            >
              View My Work
            </button>
            <button 
              onClick={() => scrollToSection('contact')}
              className="border-2 border-white text-white hover:bg-white hover:text-primary px-8 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
            >
              Get In Touch
            </button>
          </div>
          
          <div className="flex justify-center space-x-6">
            <a 
              href="https://www.linkedin.com/in/muhhamad-asim-745867b5/" 
              target="_blank" 
              rel="noopener noreferrer"
              className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-all duration-300 transform hover:scale-110"
            >
              <Linkedin className="text-xl text-white" />
            </a>
            <a 
              href="mailto:m.asim.asim@outlook.com"
              className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-all duration-300 transform hover:scale-110"
            >
              <Mail className="text-xl text-white" />
            </a>
            <a 
              href="#"
              className="w-12 h-12 bg-white bg-opacity-20 rounded-lg flex items-center justify-center hover:bg-opacity-30 transition-all duration-300 transform hover:scale-110"
            >
              <Github className="text-xl text-white" />
            </a>
          </div>
        </div>
      </div>
      
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ChevronDown className="text-2xl text-white opacity-60" size={32} />
      </div>
    </section>
  );
};

export default Hero;
