import { GraduationCap, Calendar, Award, ExternalLink } from 'lucide-react';

const Education = () => {
  const education = [
    {
      degree: "MS Artificial Intelligence",
      institution: "NED University",
      period: "2023 – 2024",
      icon: <GraduationCap className="text-2xl text-accent" />
    },
    {
      degree: "BE Electronics",
      institution: "Iqra University",
      period: "2011 – 2015",
      icon: <GraduationCap className="text-2xl text-secondary" />
    },
    {
      degree: "Intermediate (Pre-Engineering)",
      institution: "Govt. National College",
      period: "2007 – 2010",
      icon: <GraduationCap className="text-2xl text-primary" />
    },
    {
      degree: "Matriculation (Science)",
      institution: "Green House Grammar School",
      period: "2007",
      icon: <GraduationCap className="text-2xl text-gray-600" />
    }
  ];

  const certifications = [
    {
      title: "Power BI for Data Analysis",
      issuer: "Udemy",
      date: "July 15, 2025",
      instructor: "Irfan Bakaly (MVP)",
      duration: "15 total hours",
      certificateId: "UC-cc87036c-3d81-40e4-b3dd-2f473fa2068e",
      verificationUrl: "https://ude.my/UC-cc87036c-3d81-40e4-b3dd-2f473fa2068e"
    },
    {
      title: "Generative AI for Beginners",
      issuer: "Great Learning",
      date: "2025",
      verificationUrl: "https://www.mygreatlearning.com/certificate/MUMAGAXK",
      certificateId: "MUMAGAXK"
    }
  ];

  return (
    <section id="education" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-light text-center mb-16 text-primary">Education & Certifications</h2>
        
        <div className="max-w-4xl mx-auto">
          {/* Education Section */}
          <div className="mb-12">
            <h3 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
              <GraduationCap className="w-6 h-6 mr-2 text-primary" />
              Academic Qualifications
            </h3>
            <div className="space-y-6">
              {education.map((edu, index) => (
                <div key={index} className="bg-gray-50 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-md">
                      {edu.icon}
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-semibold text-gray-800 mb-2">{edu.degree}</h3>
                      <p className="text-gray-600 text-lg mb-2">{edu.institution}</p>
                      <div className="flex items-center text-gray-500">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{edu.period}</span>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Certifications Section */}
          <div>
            <h3 className="text-2xl font-semibold text-gray-800 mb-6 flex items-center">
              <Award className="w-6 h-6 mr-2 text-accent" />
              Professional Certifications
            </h3>
            <div className="space-y-6">
              {certifications.map((cert, index) => (
                <div key={index} className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-xl shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 border-accent">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-12 h-12 bg-white rounded-lg flex items-center justify-center shadow-md">
                      <Award className="text-2xl text-accent" />
                    </div>
                    <div className="flex-1">
                      <h4 className="text-xl font-semibold text-gray-800 mb-2">{cert.title}</h4>
                      <p className="text-gray-600 text-lg mb-2">{cert.issuer}</p>
                      {cert.instructor && (
                        <p className="text-gray-500 text-sm mb-2">Instructor: {cert.instructor}</p>
                      )}
                      <div className="flex items-center text-gray-500 mb-3">
                        <Calendar className="w-4 h-4 mr-2" />
                        <span>{cert.date}</span>
                        {cert.duration && (
                          <span className="ml-4 text-sm">• {cert.duration}</span>
                        )}
                      </div>
                      <div className="flex items-center space-x-4">
                        <span className="text-sm text-gray-600">Certificate ID: {cert.certificateId}</span>
                        <a 
                          href={cert.verificationUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center text-accent hover:text-blue-600 transition-colors text-sm font-medium"
                        >
                          <ExternalLink className="w-4 h-4 mr-1" />
                          Verify Certificate
                        </a>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Education;