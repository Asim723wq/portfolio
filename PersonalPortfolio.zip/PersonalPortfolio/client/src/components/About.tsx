const About = () => {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section id="about" className="py-20 bg-white text-gray-800">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl md:text-5xl font-light text-center mb-16 text-primary">About Me</h2>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p className="text-lg leading-relaxed">
                Experienced Data Analyst with 3+ years of expertise in transforming raw data into strategic 
                business insights. Specialized in Power BI dashboard development, statistical analysis, and 
                advanced data visualization techniques that drive informed decision-making across organizations.
              </p>
              
              <p className="text-lg leading-relaxed">
                With a Master's in Artificial Intelligence and proven experience at companies like Digitechtic 
                and Nastech, I excel at SQL database querying, Python-based analytics, and creating compelling 
                data narratives. My work focuses on uncovering patterns, trends, and opportunities that directly 
                impact business performance and operational efficiency.
              </p>
              
              <p className="text-lg leading-relaxed">
                Passionate about leveraging machine learning and AI technologies to enhance traditional data 
                analysis workflows. From customer segmentation to predictive modeling, I bridge the gap between 
                complex data science concepts and practical business applications.
              </p>
              
              <div className="flex flex-wrap gap-4 mt-8">
                <a 
                  href="#" 
                  className="bg-primary hover:bg-purple-700 text-white px-6 py-2 rounded-lg font-medium transition-all duration-300"
                >
                  <i className="fas fa-download mr-2"></i>Download Resume
                </a>
                <button 
                  onClick={() => scrollToSection('contact')}
                  className="border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-2 rounded-lg font-medium transition-all duration-300"
                >
                  Let's Talk
                </button>
              </div>
            </div>
            
            <div className="space-y-6">
              <div className="rounded-xl overflow-hidden shadow-2xl">
                <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=600" 
                  alt="Data analytics workspace with charts and graphs" 
                  className="w-full h-auto" 
                />
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-center">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-2xl font-bold text-primary">3+</h3>
                  <p className="text-gray-600">Years Experience</p>
                </div>
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h3 className="text-2xl font-bold text-primary">AI/ML</h3>
                  <p className="text-gray-600">Specialization</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
