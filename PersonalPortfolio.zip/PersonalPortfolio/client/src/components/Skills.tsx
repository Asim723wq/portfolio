import { Code, Server, PaintbrushVertical, Database, BarChart3, Brain, TrendingUp, Calculator, PieChart, Monitor } from 'lucide-react';
import { SiPython, SiPytorch } from 'react-icons/si';

const Skills = () => {
  const skillCategories = [
    {
      icon: <Code className="text-5xl text-accent" />,
      title: "Data Analysis",
      description: "Expert in data analysis, statistical modeling, and visualization techniques",
      technologies: ["Python", "SQL", "Power BI"]
    },
    {
      icon: <Server className="text-5xl text-secondary" />,
      title: "Machine Learning", 
      description: "Building ML models for predictive analytics and automated decision making",
      technologies: ["PyTorch", "Transformers", "BERT"]
    },
    {
      icon: <PaintbrushVertical className="text-5xl text-primary" />,
      title: "Power BI Specialty",
      description: "Expert in creating interactive dashboards and comprehensive business intelligence solutions",
      technologies: ["Power BI", "DAX", "Data Modeling"]
    }
  ];

  const technicalSkills = [
    { 
      name: "Python", 
      icon: <SiPython className="text-2xl" />,
      color: "text-yellow-500",
      bgColor: "bg-yellow-50"
    },
    { 
      name: "SQL", 
      icon: <Database className="text-2xl" />,
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    { 
      name: "Power BI", 
      icon: <BarChart3 className="text-2xl" />,
      color: "text-orange-500",
      bgColor: "bg-orange-50"
    },
    { 
      name: "PyTorch", 
      icon: <SiPytorch className="text-2xl" />,
      color: "text-red-500",
      bgColor: "bg-red-50"
    },
    { 
      name: "Data Visualization", 
      icon: <TrendingUp className="text-2xl" />,
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    { 
      name: "Statistical Analysis", 
      icon: <Calculator className="text-2xl" />,
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    { 
      name: "Business Intelligence", 
      icon: <PieChart className="text-2xl" />,
      color: "text-indigo-600",
      bgColor: "bg-indigo-50"
    },
    { 
      name: "Dashboard Design", 
      icon: <Monitor className="text-2xl" />,
      color: "text-teal-600",
      bgColor: "bg-teal-50"
    }
  ];

  return (
    <section id="skills" className="py-20 bg-gray-50">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-light text-center mb-16 text-primary">Technical Skills</h2>
        
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {skillCategories.map((category, index) => (
              <div key={index} className="skill-card bg-white p-8 rounded-xl shadow-lg text-center hover:shadow-xl transition-all duration-300">
                <div className="mb-4 flex justify-center">
                  {category.icon}
                </div>
                <h3 className="text-xl font-semibold mb-4 text-gray-800">{category.title}</h3>
                <p className="text-gray-600 mb-4">{category.description}</p>
                <div className="flex flex-wrap gap-2 justify-center">
                  {category.technologies.map((tech, techIndex) => (
                    <span key={techIndex} className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                      {tech}
                    </span>
                  ))}
                </div>
              </div>
            ))}
          </div>
          
          <div className="bg-white p-8 rounded-xl shadow-lg">
            <h3 className="text-2xl font-semibold mb-8 text-center text-gray-800">Technical Proficiencies</h3>
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {technicalSkills.map((skill, index) => (
                <div key={index} className={`${skill.bgColor} p-4 rounded-xl text-center hover:shadow-lg transition-all duration-300 transform hover:scale-105`}>
                  <div className={`w-12 h-12 mx-auto mb-3 bg-white rounded-full flex items-center justify-center shadow-md`}>
                    <div className={skill.color}>
                      {skill.icon}
                    </div>
                  </div>
                  <p className="font-medium text-gray-700">{skill.name}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Skills;
