import { ExternalLink, Github } from 'lucide-react';
import salesOverviewDashboard from '@assets/sales-overview-dashboard.png';

const Projects = () => {
  const projects = [
    {
      title: "Power BI Sales Analytics Dashboard",
      description: "Comprehensive sales analytics dashboard featuring city-wise sales analysis, product performance tracking, weather-based sales patterns, and year-over-year comparison with interactive KPIs totaling 129.37M in sales.",
      image: salesOverviewDashboard,
      technologies: ["Power BI", "DAX", "Data Modeling"],
      liveUrl: "#",
      githubUrl: "#"
    },
    {
      title: "Customer Segmentation Analysis",
      description: "Performed customer segmentation using K-Means and hierarchical clustering to identify distinct customer groups and improve marketing strategies.",
      image: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=400",
      technologies: ["Python", "K-Means", "Clustering"],
      liveUrl: "#",
      githubUrl: "#"
    },
    {
      title: "Predictive Maintenance Model",
      description: "Built a machine learning model to predict equipment failures, reducing downtime and operational costs for manufacturing processes.",
      image: "https://images.unsplash.com/photo-1581092160562-40aa08e78837?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&h=400",
      technologies: ["Python", "Machine Learning", "Predictive Analytics"],
      liveUrl: "#",
      githubUrl: "#"
    }
  ];

  return (
    <section id="projects" className="py-20 bg-white">
      <div className="container mx-auto px-6">
        <h2 className="text-4xl md:text-5xl font-light text-center mb-16 text-primary">Professional Experience</h2>
        
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <div key={index} className="project-card bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all duration-300">
                <div className="h-48 bg-gray-200 overflow-hidden">
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover" 
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-semibold mb-2 text-gray-800">{project.title}</h3>
                  <p className="text-gray-600 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {project.technologies.map((tech, techIndex) => (
                      <span key={techIndex} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-sm">
                        {tech}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-3">
                    <a 
                      href={project.liveUrl} 
                      className="text-accent hover:text-blue-600 transition-colors flex items-center"
                    >
                      <ExternalLink size={16} className="mr-1" />
                      Live Demo
                    </a>
                    <a 
                      href={project.githubUrl} 
                      className="text-gray-600 hover:text-gray-800 transition-colors flex items-center"
                    >
                      <Github size={16} className="mr-1" />
                      Code
                    </a>
                  </div>
                </div>
              </div>
            ))}
          </div>
          
          <div className="text-center mt-12">
            <a 
              href="#" 
              className="bg-primary hover:bg-purple-700 text-white px-8 py-3 rounded-lg font-medium transition-all duration-300 transform hover:scale-105"
            >
              View All Projects
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Projects;
